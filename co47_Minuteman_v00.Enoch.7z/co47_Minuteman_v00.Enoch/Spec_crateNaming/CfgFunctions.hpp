class Spec_crateNaming_ACE {
    tag = "ace_cargo";
    class init {
        file="spec_crateNaming";
        class onMenuOpen {};
    };
};
class Spec_crateNaming {
    tag = "Spec_crateNaming";
    class init {
        file="spec_crateNaming";
        class initObject {};
        class editDialog {};
    };
};