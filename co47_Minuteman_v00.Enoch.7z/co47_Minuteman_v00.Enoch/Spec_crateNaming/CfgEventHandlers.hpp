class StaticWeapon {
    class Spec_crateNaming {
        init = "_this call Spec_crateNaming_fnc_initObject";
    };
};
class ThingX {
    class Spec_crateNaming {
        init = "_this call Spec_crateNaming_fnc_initObject";
    };
};
class Land_PortableLight_single_F {
    class Spec_crateNaming {
        init = "_this call Spec_crateNaming_fnc_initObject";
    };
};