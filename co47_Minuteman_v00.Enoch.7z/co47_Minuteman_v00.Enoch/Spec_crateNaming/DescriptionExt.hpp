// add dialog by extending init handler
class Extended_Init_EventHandlers {
#include "CfgEventHandlers.hpp"
};