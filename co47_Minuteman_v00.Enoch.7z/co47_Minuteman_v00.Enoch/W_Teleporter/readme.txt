W_Teleporter v1.0.2 by [W] Fett_Li

What does this?
Well, this nice little teleporter gives you various abilities for teleporting to any player in a mission, just by script.
No objectnames needed.

How to use?

Just place following line in the initPlayerLocal.sqf in you're mission for each object which you want to be a teleporter.
Of course OBJ has to be replaced with the specific object name.
	[OBJ] call FETT_fnc_W_addTeleport;

Feel free to share and to modifiy this package, but if you do so, please mention me in the credits.
You're not allowed to publish any modified version under your own name.