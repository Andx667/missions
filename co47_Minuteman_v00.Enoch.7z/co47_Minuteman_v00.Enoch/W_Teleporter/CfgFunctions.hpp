//	W_Teleporter v1.0.1 by [W] Fett_Li

class W_Teleporter {
	tag = "FETT";
	class init {
		file = "W_Teleporter";
		class W_RscTeleportInit {};
		class W_addTeleport {};
	};
};